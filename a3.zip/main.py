#A3
Color = input("Input color: ")
if Color.lower() == "black":
    print(0)
elif Color.lower() == "brown":
    print(1)
elif Color.lower() == "red":
    print(2)
elif Color.lower() == "orange":
    print(3)
elif Color.lower() == "yellow":
    print(4)
elif Color.lower() == "green":
    print(5)
elif Color.lower() == "blue":
    print(6)
elif Color.lower() == "violet":
    print(7)
elif Color.lower() == "grey":
    print(8)
elif Color.lower() == "white":
    print(9)
else:
    print("Invalid Color")