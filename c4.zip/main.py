#C4

def loaded_divider(vs, r1, r2, rl):
    Theoretical = vs * (r2/(r1+r2))
    r2l = (r2*rl)/(r2+rl)
    Practical = vs * (r2l/(r1+r2l))
    return Theoretical, Practical