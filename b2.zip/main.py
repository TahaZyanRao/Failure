#B2

Total = 0
Series = int(input("How many resistors are connected in series?: "))
for x in range(Series):
    R = int(input("What is the value of Resistor?: "))
    Total += R 
print("The total resistance of parallel circuit is: ", Total)