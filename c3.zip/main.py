#C3

Decimal = int(input("Enter a Decimal: "))
def decimal_to_binary(Decimal):
    Binary = ""
    while Decimal != 0:
        Binary = Binary + str(Decimal%2)
        Decimal = Decimal//2
    Binary = Binary[::-1] 
    return Binary
    

print(decimal_to_binary(Decimal))

    