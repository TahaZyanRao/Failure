#C2

def Conductance(R):
    if R == 0:
        raise ValueError("Cannot calculate the reciprocal of zero.")
    return 1.0 / R


def parallel_resistance(Resistors):
    SumC = 0
    for x in range(len(Resistors)):
        SumC += Conductance(Resistors[x])
    return round(1/SumC, 2)

print(parallel_resistance([100, 200, 300]))
    