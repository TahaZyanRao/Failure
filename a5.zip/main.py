#A5
R1 = float(input("Input Resistance Value 1: "))
R2 = float(input("Input Resistance Value 2: "))
R3 = float(input("Input Resistance Value 3: "))

if R1>R2:
    if R1>R3:
        print("Largest R: ", R1) 
        print("Smallest R: ", R2)
    else:
        print("Largest R: ", R3) 
        print("Smallest R: ", R2)
else:
    if R2>R3:
        print("Largest R: ", R2) 
        print("Smallest R: ", R1)
    else:
        print("Largest R: ", R3) 
        print("Smallest R: ", R1)
    