#C5
def star_to_delta(A, B, C):
    Numerator = (A*B) + (A*C) + (B*C)
    A_B = Numerator/C 
    B_C = Numerator/A
    A_C = Numerator/B 
    return round(A_B, 2), round(A_C, 2), round(B_C, 2)
    
print(star_to_delta(10, 20, 30))
