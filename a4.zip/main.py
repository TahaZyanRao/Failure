#A4
A = int(input("Input bit A (Can only be 1 or 0)"))
B = int(input("Input bit B (Can only be 1 or 0)"))
while A!= 0 and B!= 0: 
    A = int(input("Input bit A (Can only be 1 or 0)"))
    B = int(input("Input bit B (Can only be 1 or 0)"))

def AND(A, B):
    if A = 1 and B = 1:
        return 1
    else:
        return 0

def OR(A, B):
    if A == 0 and B == 0:
        return 0
    else:
        return 1

def XOR(A, B):
    if A!=B:
        return 1
    else:
        return 0
        
