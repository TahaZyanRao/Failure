#B5
Ohm = float(input("Input measured resistance value: "))
OnePercent = 0
FivePercent = 0
Rejected = 0
while Ohm != 0:
    if 99.0<=Ohm<=101.0:
        OnePercent += 1
    elif 95.0<=Ohm<=105.0:
        FivePercent += 1
    else:
        Rejected += 1
    Ohm = float(input("Input measured resistance value: "))
print("Resistors of 1% tolerance: ", OnePercent)
print("Resistors of 5% tolerance: ", FivePercent)
print("Faulty/Rejected resistors: ", Rejected)