#A2
CurrentAB = float(input("Input Current Value: "))
if CurrentAB>0:
    print("Current flows from A to B")
else:
    print("Current flows from B to A")