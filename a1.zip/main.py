#A1 
V = float(input("Enter Volatge (In Volts): "))
R = float(input("Enter Resistance (In Ohms): "))
I = V/R 
if I>2:
    print("Fuse will Blow.")
else:
    print("Circuit is Safe.")