#B3

readings = [3.3, 3.1, 3.4, 2.9, 3.6, 3.0, 3.2]
Above = 0
Max = 0
Min = 10
Sum = 0

for x in range(len(readings)):
    if readings[x]>3.2:
        Above += 1
    if readings[x]>Max:
        Max = readings[x]
    elif readings[x]<Min:
        Min = readings[x]
    Sum += readings[x]

print("Readings above 3.2V: ", Above)
print("Highest: ", Max)
print("Lowest: ", Min)
print("Average: ", round(Sum/len(readings), 2))

