#B1

R = 10
for V in range(1,11):
    print(V/R)
    