#C1

global I
global P

def ohms_current(V, R):
    global I 
    I = V/R  
    return I 

def power_dissipated(I, R):
    P = (I**2) * R 
    return P

print(ohms_current(12, 6))
print(power_dissipated(I, 6))