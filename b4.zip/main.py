#B4
voltages = [12.6, 12.5, 12.5, 12.3, 12.1, 11.9, 12.0, 11.8, 11.6, 11.5, 11.5, 11.2]
Streak = 1
Max = 0
Start = 0
End = 0
A = 0
for x in range(1, len(voltages)):
    if voltages[x]<voltages[x-1]:
        Streak+=1
    else:
        Streak = 1
        A = x 
    if Streak>Max:
        Max = Streak
        Start = A

End = Start + Max - 1

print("Longest continuous drop (In minutes): ", Max)
print("Started At: ", voltages[Start])
print("Ended At: ", voltages[End])
